"""Export the director's screenplay and production text; do not render media."""

import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FILM = json.loads((ROOT / "film-v3.json").read_text(encoding="utf-8"))
CJK = re.compile(r"[\u3400-\u9fff]")
DEVELOPMENT_COPY = re.compile(r"\b(prototype|simulat\w*|planned|next step|not yet)\b", re.I)


def tc(seconds):
    minutes, remainder = divmod(seconds, 60)
    return f"{minutes:02}:{remainder:02}"


def srt_tc(seconds):
    return f"00:{tc(seconds)},000"


def save(name, lines):
    path = ROOT / name
    content = "\n".join(lines) if isinstance(lines, list) else lines
    path.write_text(content, encoding="utf-8-sig")
    return path


def validate_film():
    assert FILM["duration"] == 118
    assert len(FILM["source_shots"]) == 26
    assert len(FILM["beats"]) == 59
    assert [b["t"] for b in FILM["beats"]] == list(range(0, 118, 2))
    for collection in ("sequences", "source_shots"):
        cursor = 0
        for item in FILM[collection]:
            assert item["start"] == cursor and item["end"] > cursor
            cursor = item["end"]
        assert cursor == 118
    shots = {shot["id"]: shot for shot in FILM["source_shots"]}
    for beat in FILM["beats"]:
        shot = shots[beat["shot"]]
        assert shot["start"] <= beat["t"] < beat["t"] + 2 <= shot["end"]
        for label in beat["text"]:
            assert not CJK.search(label), label
            assert not DEVELOPMENT_COPY.search(label), label
    previous_end = 0
    for cue in FILM["voiceover"]:
        assert previous_end <= cue["start"] < cue["end"] <= 118
        assert not CJK.search(cue["en"])
        assert not DEVELOPMENT_COPY.search(cue["en"])
        previous_end = cue["end"]
        words = re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", cue["en"])
        assert len(words) / (cue["end"] - cue["start"]) <= 2.8
    assert previous_end == 118
    for shot in FILM["source_shots"]:
        assert shot["mode"] in {"T2V", "COMPOSITE"}
        assert not CJK.search(shot["prompt_en"])
    return shots


def treatment():
    lines = [
        FILM["title"],
        "导演阐述 / V3",
        "118秒 | 英文画面 | 英文旁白 | 中英双语字幕",
        "",
        "一句话故事",
        FILM["logline_zh"],
        "",
        "本次重写的根本变化",
        "不是把产品介绍做得更响、更快，而是让一件具体事情发生：一个地点被识别，一项决定变成行动，一条居民反馈改变现场安排，结果回到居民。",
        "全片的核心价值不是另一张天气图，也不是四个Agent的名字；是风险与城市行动之间的距离被缩短。",
        "关键视觉承诺：开头同一条下穿通道，结尾同一构图，屏障已经在前景。观众不需要一句夸张数字，就能理解事前准备的价值。",
        "",
        "作品叙事语境（仅制作团队阅读，不上屏）",
        FILM["authoring_context_zh"],
        "",
        "角色与视角",
        FILM["creative_choice_zh"],
        "",
        "画面语言",
        FILM["screen_policy_zh"],
        "",
        "十二段叙事",
    ]
    for seq in FILM["sequences"]:
        lines.extend([
            f"{tc(seq['start'])}-{tc(seq['end'])}  {seq['name_zh']}",
            f"叙事任务：{seq['purpose_zh']}",
            f"观众得到：{seq['reveal_zh']}",
            "",
        ])
    for heading, key in [
        ("摄影与运镜", "camera_zh"),
        ("焦段与清晰度", "lenses_zh"),
        ("场景、光线、色彩", "lighting_zh"),
        ("音乐结构", "music_zh"),
        ("声音记忆点", "sound_motif_zh"),
        ("混音", "mix_zh"),
        ("剪辑逻辑", "edit_zh"),
        ("人物与空间连续性", "continuity_zh"),
        ("生成与后期分工", "generation_zh"),
        ("灾难场景处理", "safety_zh"),
    ]:
        lines.extend([heading, FILM["direction"][key], ""])
    lines.extend(["配音选角", FILM["voices"]["casting_zh"], "", "配音情绪弧线", FILM["voices"]["arc_zh"], ""])
    lines.extend(["重要的无旁白窗口", "08-10、16-18、52-54、88-90、104-106秒。不是忘记写词，是让看见、批准、雨声和人的反应承担叙事。", ""])
    return save("01_director_treatment_ZH.txt", lines)


def storyboard():
    lines = [
        FILM["title"],
        "每2秒导演分镜 | 59个剪辑节拍，不是59个独立生成镜头",
        "本文件中的章节标题、镜头号、导演说明、音效说明都不上屏。",
        "画面正文仅采用各条“英文画面文字”；“无新增”表示不加新的文字，不要求把上一行立即清空。",
        "界面内文字按一个完整镜头保留，不做每两秒闪烁切换。已出现的地点和证据在相关段落保持可见。",
        "",
    ]
    for seq in FILM["sequences"]:
        lines.extend([
            "=" * 64,
            f"{seq['id']} | {tc(seq['start'])}-{tc(seq['end'])} | {seq['name_zh']}",
            f"目的：{seq['purpose_zh']}",
            "",
            "本段旁白与字幕：",
        ])
        for cue in FILM["voiceover"]:
            if seq["start"] <= cue["start"] < seq["end"]:
                lines.extend([
                    f"{tc(cue['start'])}-{tc(cue['end'])}  {cue['en']}",
                    cue["zh"],
                    f"配音方向：{cue['performance_zh']}",
                ])
        lines.append("")
        for beat in FILM["beats"]:
            if seq["start"] <= beat["t"] < seq["end"]:
                labels = " | ".join(beat["text"]) or "无新增"
                lines.extend([
                    f"{tc(beat['t'])}-{tc(beat['t'] + 2)}  [{beat['shot']}]",
                    f"画面：{beat['visual_zh']}",
                    f"运镜／剪辑：{beat['move_zh']}",
                    f"英文画面文字：{labels}",
                    f"声音：{beat['sound_zh']}",
                    "",
                ])
    return save("02_storyboard_2s_ZH.txt", lines)


def voiceover():
    lines = [
        FILM["title"], "英文配音台本 + 中文译文 + 表演方向", "",
        FILM["voices"]["casting_zh"], "", FILM["voices"]["arc_zh"], "",
        FILM["voices"]["pronunciation_zh"], "", FILM["voices"]["subtitle_zh"], "",
    ]
    for cue in FILM["voiceover"]:
        lines.extend([
            f"{tc(cue['start'])}-{tc(cue['end'])}",
            f"EN  {cue['en']}",
            f"ZH  {cue['zh']}",
            f"表演  {cue['performance_zh']}",
            "",
        ])
    return save("03_voiceover_bilingual.txt", lines)


def subtitles():
    paths = []
    for language in ("bilingual", "EN", "ZH"):
        blocks = []
        for index, cue in enumerate(FILM["voiceover"], 1):
            words = {
                "bilingual": f"{cue['en']}\n{cue['zh']}",
                "EN": cue["en"],
                "ZH": cue["zh"],
            }[language]
            blocks.append(f"{index}\n{srt_tc(cue['start'])} --> {srt_tc(cue['end'])}\n{words}\n")
        paths.append(save(f"04_subtitles_{language}.srt", "\n".join(blocks)))
    return paths


def prompts():
    lines = [
        "URBAN RISK COPILOT — AHEAD OF THE STORM",
        "26 SOURCE SHOTS — ENGLISH GENERATION AND COMPOSITING BRIEF",
        "",
        "This is a screenplay under a completed-product premise, not evidence of live deployment.",
        "No media or voice is generated by this package. No model-specific ComfyUI workflow is supplied.",
        "T2V = generate a clean scene plate. COMPOSITE = build controlled graphics in editing; the prompt describes the blank visual plate.",
        "Match each source-shot duration below in the edit; your model may need a longer supported frame count.",
        "Do not ask a video model to render words. English UI and bilingual subtitles are separate post-production layers.",
        "A reused seed does not guarantee character or location identity. Use reference frames if your installed workflow supports them.",
        "For P02/P20, use the same layout reference, or the same background plate with rain and barriers composited separately.",
        "P04/P06/P07/P08/P09/P11/P16/P22 must use ONE consistent interface design, not independently invented dashboards.",
        "",
    ]
    for shot in FILM["source_shots"]:
        lines.extend([
            "=" * 72,
            f"{shot['id']} | {tc(shot['start'])}-{tc(shot['end'])} | {shot['end'] - shot['start']} seconds | {shot['mode']}",
            "",
            "COMPLETE POSITIVE PROMPT",
            FILM["generation_global_en"] + " " + shot["prompt_en"],
            "",
            "NEGATIVE PROMPT",
            FILM["negative_en"],
            "",
            "POST-PRODUCTION TEXT, NOT MODEL-GENERATED LETTERING",
        ])
        for beat in FILM["beats"]:
            if beat["shot"] == shot["id"]:
                line = " | ".join(beat["text"]) or "(no new text; retain relevant interface context)"
                lines.append(f"{tc(beat['t'])}-{tc(beat['t'] + 2)}: {line}")
        lines.append("")
    content = "\n".join(lines)
    assert not CJK.search(content)
    return save("05_source_shot_prompts_EN.txt", content)


def ui_copy():
    lines = [
        "URBAN RISK COPILOT — ENGLISH SCREEN COPY",
        "",
        "EDITOR INSTRUCTIONS — NOT ON SCREEN",
        "Only the quoted copy in the timeline belongs in the picture.",
        "Chinese appears exclusively in the separate Chinese subtitle line.",
        "Keep one road name across every interface: XINGYUAN UNDERPASS.",
        "Keep the map, evidence and response plan visually continuous from 28 to 54 seconds.",
        "Approval precedes dispatch and the resident alert.",
        "A resident report is reviewed, not automatically treated as confirmed sensor truth.",
        "Completion at 98 seconds applies to the drain-check task, not to the flood incident.",
        "RISK MONITORING ACTIVE remains visible while the resident receives the update.",
        "No invented confidence, accuracy, flood-depth or response-time values.",
        "No new text means do not introduce a new label; retain relevant existing UI text.",
        "Do not show director notes, stage-of-development commentary or file names.",
        "",
        "TIMELINE — PICTURE COPY ONLY",
    ]
    for beat in FILM["beats"]:
        if beat["text"]:
            lines.append(f"{tc(beat['t'])}-{tc(beat['t'] + 2)}: " + " | ".join(beat["text"]))
    lines.extend([
        "",
        "APPROVAL-PANEL UI HIERARCHY",
        "Location: XINGYUAN UNDERPASS",
        "Risk: FLOOD RISK | PRIORITY: HIGH",
        "Evidence: RISING WATER | LOW-LYING ROAD | FLOOD HISTORY",
        "Plan: CHECK DRAINAGE | PREPARE TRAFFIC CONTROL | DRAFT RESIDENT ALERT",
        "Primary action: APPROVE & DISPATCH",
        "Recipient views: DRAINAGE | TRAFFIC | RESIDENTS",
        "",
        "RESIDENT REPORT",
        "RESIDENT REPORT",
        "Blocked drain near the underpass.",
        "VIA WECHAT",
        "XINGYUAN UNDERPASS",
        "REPORT RECEIVED",
        "",
        "RESIDENT UPDATE",
        "Drain cleared. Road restriction remains.",
        "",
        "END CARD — HOLD BOTH LINES FOR FOUR SECONDS",
        "Urban Risk Copilot",
        "AHEAD OF THE STORM.",
    ])
    content = "\n".join(lines)
    assert not CJK.search(content)
    return save("06_screen_copy_EN.txt", content)


def critique():
    section = FILM["critique"]
    lines = [
        FILM["title"], "导演自评、取舍与提升点", "", section["verdict_zh"], "",
        "为什么前版不够好",
    ]
    lines.extend(f"{i}. {s}" for i, s in enumerate(section["previous_failures_zh"], 1))
    lines.extend(["", "六项评价"])
    for item in section["assessment"]:
        lines.extend([
            f"\n{item['dimension_zh']}",
            f"判断：{item['judgment_zh']}",
            f"仍有问题：{item['remaining_risk_zh']}",
            f"具体提升：{item['improvement_zh']}",
        ])
    lines.extend(["", "按价值排序的制作投入"])
    lines.extend(f"{i}. {s}" for i, s in enumerate(section["priority_improvements_zh"], 1))
    lines.extend(["", "架构如何进入电影，而不是上墙"])
    for item in FILM["architecture_map"]:
        lines.extend([
            f"{item['time']}秒 | 架构章节 {item['reference']}",
            item["meaning_zh"],
            f"镜头转译：{item['screen_translation_zh']}",
            "",
        ])
    lines.extend(["导演审片问题"])
    lines.extend(f"{i}. {s}" for i, s in enumerate(section["review_questions_zh"], 1))
    lines.extend([
        "",
        "结论",
        "本版把投入集中到一个地点、一个决定和一个反馈闭环，能比功能巡礼更有记忆点。",
        "但最终质感取决于英文界面的可读性、两次下穿通道构图的一致性和旁白表演；文字脚本不能保证生成结果或获奖。",
        "不建议先扩充台词、再增加灾种、再堆特效。先把三个核心组做对：28-54秒产品因果链、84-92秒锁扣与风雨、98-106秒居民回执。",
    ])
    return save("07_director_review_ZH.txt", lines)


def verify_export(paths):
    for path in paths:
        assert path.exists() and path.stat().st_size > 0
        if path.suffix == ".srt":
            blocks = path.read_text(encoding="utf-8-sig").strip().split("\n\n")
            assert len(blocks) == len(FILM["voiceover"])
            for cue, block in zip(FILM["voiceover"], blocks):
                lines = block.splitlines()
                assert lines[1] == f"{srt_tc(cue['start'])} --> {srt_tc(cue['end'])}"
                assert len(lines) == (4 if "bilingual" in path.name else 3)
        assert path.suffix in {".txt", ".srt", ".json", ".py"}


def main():
    validate_film()
    paths = [
        treatment(), storyboard(), voiceover(), *subtitles(),
        prompts(), ui_copy(), critique(), ROOT / "film-v3.json", Path(__file__).resolve(),
    ]
    verify_export(paths)
    archive_path = ROOT / "Urban_Risk_Copilot_Film_V3_TextPack.zip"
    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            archive.write(path, arcname=path.name)
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(paths)
    words = sum(len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", cue["en"])) for cue in FILM["voiceover"])
    print(f"Created {archive_path}")
    print(f"{len(FILM['beats'])} beats; {len(FILM['source_shots'])} source shots; "
          f"{len(FILM['voiceover'])} subtitle cues; {words} English narration words; 118 seconds.")
    print("Text-only export. No images, audio or video generated.")


if __name__ == "__main__":
    main()
